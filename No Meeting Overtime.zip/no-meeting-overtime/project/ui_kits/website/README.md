# Lights Out — Website UI kit

A high-fidelity recreation of the Lights Out marketing site and the signed-in flow.

## Screens
- **`LandingScreen.jsx`** (`window.LandingScreen`) — nav, hero with the moon motif and
  the floating "end this call at" product card, plus the three-step "how it works" row.
  Prop: `onSignIn()`.
- **`DashboardScreen.jsx`** (`window.DashboardScreen`) — the signed-in home for the one
  call you're in: shows its end time, time left and progress, with "Change end time" /
  "End now" (and an empty state when nothing is running). Props: `onNewCall()`, `onSignOut()`.
- **`SetTimeScreen.jsx`** (`window.SetTimeScreen`) — choose tonight's end time from a chip
  grid and start the call, then a "scheduled" confirmation state. Prop: `onBack()`.

## Run
Open `index.html`. It loads React + Babel, links the root `styles.css` for tokens, and
wires the screens together: Landing → (Sign in) → Dashboard → (New call) → Set time →
(Start the call) → scheduled confirmation.

These screens recreate the existing design; they compose the same tokens as the
`components/core` primitives (Button, Card, Badge, TimeChip, MoonMark).
