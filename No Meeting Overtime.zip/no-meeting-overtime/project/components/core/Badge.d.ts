import React from "react";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** tint = outlined blue pill (default); solid = filled accent. */
  tone?: "tint" | "solid";
  children?: React.ReactNode;
}

export declare function Badge(props: BadgeProps): JSX.Element;
