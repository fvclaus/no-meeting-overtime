import React from "react";

/**
 * Small pill label, mode-aware.
 *   tint  — accent-outlined pill (status, e.g. "Live")
 *   solid — filled accent pill
 * Reads --m-* tokens with legacy night fallback.
 */
export function Badge({ tone = "tint", children, style = {}, ...rest }) {
  const tones = {
    tint: {
      color: "var(--m-accent, var(--blue-500))",
      border: "1px solid rgba(var(--m-accent-rgb, 93,139,255), 0.40)",
      background: "transparent",
    },
    solid: {
      color: "var(--m-ink, var(--blue-ink))",
      border: "1px solid transparent",
      background: "var(--m-accent, var(--blue-500))",
    },
  };
  const t = tones[tone] || tones.tint;
  return (
    <span
      {...rest}
      style={{
        display: "inline-flex",
        alignItems: "center",
        font: "600 12px/1 var(--font-body)",
        padding: "6px 10px",
        borderRadius: "var(--radius-pill)",
        ...t,
        ...style,
      }}
    >
      {children}
    </span>
  );
}
