---
name: lights-out-design
description: Use this skill to generate well-branded interfaces and assets for Lights Out, a non-profit tool that ends late-night Google Meet calls at a chosen time. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping or production.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key facts to honor:
- Nighttime palette: navy surfaces (#0b1322 page, #111d33 card), ONE calm-blue accent (#5d8bff), soft "moon" off-white (#dfe8ff). No second accent, no gradients-as-fills.
- Type: Space Grotesk (headings + numerals, tight tracking), Hanken Grotesk (body/UI). Sentence case; the only uppercase is the tracked eyebrow.
- The moon crescent is the brand mark — a CSS circle with an inset page-colored shadow. Never draw it as SVG/image.
- Voice: plain, sincere, quiet. No hype, no jokes, no invented features. Always note "Free, non-profit, no ads." No emoji.
