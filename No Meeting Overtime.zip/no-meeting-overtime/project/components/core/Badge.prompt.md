Tiny status pill — e.g. "Auto", "Tonight" on the product card.

```jsx
<Badge tone="tint">Auto</Badge>
```

`tint` (outlined, default) for quiet status; `solid` to highlight. Keep the label one or two words, sentence case.
