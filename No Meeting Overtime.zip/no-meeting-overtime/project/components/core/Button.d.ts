import React from "react";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual weight. primary = solid blue (default); secondary = solid moon-white; ghost = translucent on dark. */
  variant?: "primary" | "secondary" | "ghost";
  /** md (default, CTA) or sm (nav / compact). */
  size?: "md" | "sm";
  /** Stretch to container width. */
  full?: boolean;
  /** Optional icon node placed before the label (e.g. the Google G). */
  leadingIcon?: React.ReactNode;
  children?: React.ReactNode;
}

export declare function Button(props: ButtonProps): JSX.Element;
