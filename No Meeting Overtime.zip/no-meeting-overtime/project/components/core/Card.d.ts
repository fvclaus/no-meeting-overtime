import React from "react";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Adds the deep drop shadow used when the card floats over the sky. Default true. */
  floating?: boolean;
  /** CSS padding shorthand. Default "28px". */
  padding?: string;
  /** Corner radius. Default "var(--radius-xl)". */
  radius?: string;
  children?: React.ReactNode;
}

export declare function Card(props: CardProps): JSX.Element;
