/* Lights Out — Landing screen. Attaches to window.LandingScreen.
   Recreates the marketing landing: nav, hero with moon + floating product
   card, and the three-step "how it works" row. */
(function () {
  const { useState } = React;
  const G = "../../assets/google-g.svg";

  function GoogleBtn({ children, onClick, primary = true }) {
    return (
      <button
        onClick={onClick}
        style={{
          display: "inline-flex", alignItems: "center", gap: 10, cursor: "pointer",
          background: primary ? "var(--blue-500)" : "var(--moon)", color: "var(--blue-ink)",
          font: "600 16px/1 var(--font-body)", padding: "16px 24px",
          border: "none", borderRadius: "var(--radius-lg)",
        }}
      >
        <img src={G} alt="" width="17" height="17" style={{ display: "block" }} />
        {children}
      </button>
    );
  }

  function Step({ n, title, body }) {
    return (
      <div style={{ flex: 1 }}>
        <div style={{ font: "var(--type-step)", color: "var(--text-step)", marginBottom: 14 }}>{n}</div>
        <div style={{ font: "600 17px/1.3 var(--font-body)", color: "var(--text-bright)", marginBottom: 7 }}>{title}</div>
        <div style={{ font: "var(--type-small)", color: "var(--text-muted)" }}>{body}</div>
      </div>
    );
  }

  window.LandingScreen = function LandingScreen({ onSignIn }) {
    return (
      <div style={{ background: "var(--night-900)", minHeight: "100%", position: "relative", overflow: "hidden", fontFamily: "var(--font-body)" }}>
        {/* moon */}
        <div style={{
          position: "absolute", top: 92, right: 120, width: 150, height: 150, borderRadius: "50%",
          background: "var(--moon)", boxShadow: "var(--moon-crescent), var(--moon-halo)",
          animation: "lo-glow-pulse 6s ease-in-out infinite", pointerEvents: "none",
        }} />

        {/* nav */}
        <div style={{ position: "relative", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "26px 56px", borderBottom: "1px solid var(--night-line)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
            <div style={{ width: 24, height: 24, borderRadius: "50%", background: "var(--moon)", boxShadow: "var(--moon-crescent-sm)" }} />
            <span style={{ font: "var(--type-logo)", letterSpacing: "var(--track-tight)", color: "var(--text-hi)" }}>Lights Out</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 30 }}>
            <span style={{ font: "var(--type-ui)", color: "var(--text-muted)" }}>How it works</span>
            <span style={{ font: "var(--type-ui)", color: "var(--text-muted)" }}>Questions</span>
            <button onClick={onSignIn} style={{ display: "inline-flex", alignItems: "center", gap: 9, background: "var(--blue-500)", color: "var(--blue-ink)", font: "var(--type-label)", padding: "11px 16px", border: "none", borderRadius: "var(--radius-md)", cursor: "pointer" }}>
              <img src={G} alt="" width="17" height="17" style={{ display: "block" }} /> Sign in
            </button>
          </div>
        </div>

        {/* hero */}
        <div style={{ position: "relative", display: "flex", gap: 56, alignItems: "center", padding: "84px 56px 60px" }}>
          <div style={{ width: "56%" }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, font: "var(--type-eyebrow)", letterSpacing: "var(--track-eyebrow)", textTransform: "uppercase", color: "var(--accent)", marginBottom: 26 }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--accent)" }} />
              A simple end time for late calls
            </div>
            <h1 style={{ font: "var(--type-hero)", letterSpacing: "var(--track-hero)", color: "var(--text-bright)", margin: "0 0 22px" }}>Set when the call ends.</h1>
            <p style={{ font: "var(--type-lead)", color: "var(--text-body)", margin: "0 0 36px", maxWidth: "var(--maxw-copy)" }}>
              Tell Lights Out what time your Google Meet call should finish. When you reach it, the call closes on its own — so a good conversation with a friend doesn't quietly take your morning with it.
            </p>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <GoogleBtn onClick={onSignIn}>Sign in with Google</GoogleBtn>
              <span style={{ font: "var(--type-ui)", color: "var(--text-faint)" }}>Works with Google Meet</span>
            </div>
          </div>

          <div style={{ width: "44%", display: "flex", justifyContent: "flex-end" }}>
            <div style={{ width: "var(--card-w)", background: "var(--night-700)", border: "1px solid var(--night-line-strong)", borderRadius: "var(--radius-xl)", padding: 28, boxShadow: "var(--shadow-card)" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 22 }}>
                <span style={{ font: "500 14px/1 var(--font-body)", color: "var(--text-muted)" }}>End this call at</span>
                <span style={{ font: "600 12px/1 var(--font-body)", color: "var(--blue-500)", border: "1px solid var(--blue-tint-40)", padding: "6px 10px", borderRadius: "var(--radius-pill)" }}>Auto</span>
              </div>
              <div style={{ font: "var(--type-display)", letterSpacing: "var(--track-display)", color: "var(--text-bright)", marginBottom: 6 }}>11:15 <span style={{ fontSize: 22, color: "var(--text-muted)" }}>PM</span></div>
              <div style={{ font: "var(--type-small)", color: "var(--text-faint)", marginBottom: 22 }}>We close the call at this time, so you don't have to watch the clock.</div>
              <div style={{ display: "flex", gap: 8, marginBottom: 22 }}>
                {["11:00", "11:15", "11:30"].map((t) => (
                  <span key={t} style={{ flex: 1, textAlign: "center", font: t === "11:15" ? "600 14px/1 var(--font-body)" : "500 14px/1 var(--font-body)", color: t === "11:15" ? "var(--blue-ink)" : "var(--text-body)", background: t === "11:15" ? "var(--blue-500)" : "var(--fill-05)", padding: "11px 0", borderRadius: "var(--radius-sm)" }}>{t}</span>
                ))}
              </div>
              <button onClick={onSignIn} style={{ width: "100%", textAlign: "center", font: "600 15px/1 var(--font-body)", color: "var(--blue-ink)", background: "var(--blue-500)", padding: "15px 0", border: "none", borderRadius: "var(--radius-lg)", cursor: "pointer" }}>Start the call</button>
            </div>
          </div>
        </div>

        {/* how it works */}
        <div style={{ position: "relative", display: "flex", padding: "24px 56px 60px", gap: 44 }}>
          <Step n="01" title="Sign in with Google" body="Connect the account you start Meet calls from." />
          <Step n="02" title="Pick an end time" body="Choose it before the call, while it's easy to decide." />
          <Step n="03" title="The call ends on time" body="It closes itself at the time you set. Free, non-profit, no ads." />
        </div>
      </div>
    );
  };
})();
