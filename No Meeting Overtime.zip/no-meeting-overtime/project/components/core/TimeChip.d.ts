import React from "react";

export interface TimeChipProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Filled accent when this is the chosen end time. */
  selected?: boolean;
  children?: React.ReactNode;
}

export declare function TimeChip(props: TimeChipProps): JSX.Element;
