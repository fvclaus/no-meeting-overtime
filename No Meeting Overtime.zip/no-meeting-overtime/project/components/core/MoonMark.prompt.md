The brand mark — a CSS crescent moon. Use `withWord` for the nav logo, `glow` + a large `size` for the hero backdrop.

```jsx
<MoonMark withWord />                 {/* nav lockup */}
<MoonMark size={150} glow />          {/* hero, top-right */}
```

Never recreate the moon as an SVG or image — it's a circle with an inset page-colored shadow so it always sits correctly on `--night-900`.
