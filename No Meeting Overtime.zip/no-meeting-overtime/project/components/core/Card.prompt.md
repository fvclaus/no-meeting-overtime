Surface container for grouped content — the product/"set the end time" panel, settings blocks, etc.

```jsx
<Card floating padding="28px" style={{ width: 366 }}>
  …
</Card>
```

Use `floating` only when the card sits over the hero (adds the deep shadow). Otherwise it's a flat night-700 surface with a hairline border and 16px corners.
