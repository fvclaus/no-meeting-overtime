# Lights Out — Design System

A small brand + UI system for **Lights Out**, a non-profit tool that ends late-night
Google Meet calls at a time you choose, so a good conversation with a friend doesn't
quietly take your morning with it.

> Reframed from the open-source project **No Meeting Overtime**
> (https://github.com/fvclaus/no-meeting-overtime). The original mechanic — sign in
> with Google → set an end time → the call ends itself — is unchanged. Lights Out moves
> the *focus* from business punctuality to looking after your sleep on personal calls.

## What this is
- A **day-and-night visual language**: the product's surface tracks the sun and moon across
  the sky, so the same screen restyles itself through **four modes — dawn · day · dusk · night**.
  Each mode is a complete, self-contained palette (two light, two dark).
- One calm accent *per mode*, a soft celestial motif (sun by day, moon by night), and rounded,
  friendly display type.
- Honest, plain copy. Non-profit, no ads, nothing to sell — and the writing never pretends otherwise.
- Tokens, a handful of reusable components, and a website UI kit recreating the landing page.

> **Two layers live here.** The original single-mode **Lights Out** night styling (deep navy,
> blue accent, Space Grotesk) is preserved as the *legacy* layer for the existing UI kit. New
> work uses the **mode system** below: `data-mode="dawn|day|dusk|night"` + the `--m-*` tokens,
> with **Fredoka** display type and pill buttons. `night` mode is the bridge between the two —
> it is the brand's home look in the new token vocabulary.

---

## CONTENT FUNDAMENTALS

**Voice:** plain, sincere, quiet. It talks *to* the reader as "you", and refers to the
product by name ("Lights Out closes the call for you"). Never hype, never jokey, never a
hard sell. It states what the product does in ordinary words and stops.

**Casing:** Sentence case everywhere — headings, buttons, labels. The only uppercase is
the small tracked **eyebrow/overline** above a headline (e.g. `A SIMPLE END TIME FOR LATE CALLS`).

**Tone examples (approved):**
- Hero: *"Set when the call ends."*
- Lead: *"Tell Lights Out what time your Google Meet call should finish. When you reach it,
  the call closes on its own — so a good conversation with a friend doesn't quietly take
  your morning with it."*
- Card: *"We close the call at this time, so you don't have to watch the clock."*
- Footer line, always present: *"Free, non-profit, no ads."*

**Avoid:** exclamation marks, "supercharge / effortless / seamless", invented features
(e.g. don't claim sleep tracking or alarms — the product only ends the call), urgency,
testimonials, fake metrics.

**Emoji:** none.

---

## MODES — the four palettes

The app's look is driven by the time of day. Set `data-mode` on a container and every
`--m-*` token resolves to that mode (`:root` defaults to **night**). Within a single mode
there is still exactly **one** accent — used for the primary button, the eyebrow dot, the
slider, step numerals and focus rings. Never mix accents across modes on one screen.

| Mode  | Surface | Sky | Accent | Heading | Google button |
|-------|---------|-----|--------|---------|---------------|
| **Dawn**  | light | lilac → peach sunrise | `#e07a5f` coral | `#3b2a3f` | light |
| **Day**   | light | blue → warm-white midday | `#2f7fd6` blue | `#16263e` | light |
| **Dusk**  | dark  | plum → magenta sunset | `#ff9e6b` amber | `#f6ecf2` | dark |
| **Night** | dark  | near-black navy | `#79b4ec` blue | `#f3f4ff` | dark |

**Sky.** Every mode's page background is a soft vertical gradient (`--m-sky`) — not a flat
fill. A faint radial glow in the accent sits behind the celestial body. No photography.

**Surfaces.** Cards and the top bar are *translucent* fills (`--m-card`, `--m-header-bg`)
blurred over the sky, with a 1px hairline (`--m-card-border`) — never a hard line. Light
modes use a near-white card; dark modes a tinted-navy card.

**Text.** Each mode ships its own ramp: `--m-heading` → `--m-body` → `--m-muted` → `--m-nav`.
Light modes read dark-on-light; dark modes light-on-dark. `--m-ink` is the color that sits
*on* the accent fill (white/dark depending on mode).

---

## VISUAL FOUNDATIONS

**The celestial motif.** The hero centerpiece is a **sun** (warm radial gradient + glow,
palette per mode) in dawn/day/dusk and a **moon** (cratered off-white sphere) at night. It
arcs across the sky as the time changes and breathes slowly (`floatBob`, ~8s). Dawn/day skies
carry drifting clouds; dusk/night carry a starfield (dim at dusk, full at night).

**The moon.** The brand mark and hero motif is a crescent moon made with a single inset
shadow the color of the page carving a circle of `--moon #dfe8ff`, with a soft blue halo
(`--moon-halo`) behind it. It breathes slowly (`lo-glow-pulse`, ~6s). It appears at logo
scale in the nav and large in the top-right of dark hero sections.

**Type.** Two families in the mode system. **Fredoka** (rounded) for headings, the logo and
all numerals (clock time, step numbers), set tight (`-0.03em`) — it carries the softer,
friendlier feel. **Hanken Grotesk** for body, UI and labels. Hero ~46–68px/700; the clock
numeral 52px/700; body lead 18–19px/1.6. (Legacy Lights Out surfaces still use **Space
Grotesk** for display — `--font-display` — but new work uses `--font-display-mode`.)

**Backgrounds.** Flat dark fills — no photography, no gradients as fills. The only radial
gradients are soft glows behind the moon. No textures, no patterns.

**Cards.** `--radius-xl` (16px) corners, `--night-700` fill, 1px `--night-line-strong`
border, and a single deep soft shadow (`--shadow-card`) only when the card floats over the
hero. Inner chips/fields use `--fill-05` on `--radius-sm`.

**Buttons.** Primary = solid `--m-accent` fill, `--m-ink` text, **pill** radius (999px) in
the mode system. Secondary / ghost = transparent fill with a `--m-card-border` hairline and
`--m-heading` text. No scale, no bounce.

**Google sign-in (compliance).** The "Sign in with Google" button must follow Google's brand
rules — it is NOT painted in the mode accent. Use **Roboto Medium** (`--font-google`), the
unaltered four-color "G", an approved label, and one of Google's two themes chosen by
`--m-google-theme`: **light** button (white `#fff`, `#1f1f1f` text, `#747775` border) for
dawn/day; **dark** button (`#131314`, `#e3e3e3` text, `#8e918f` border) for dusk/night.

**Motion.** Minimal and soft (`--ease-soft`, 140–220ms). The only ambient animation is the
moon's slow opacity breathe. Fades over moves; nothing bounces.

**Radii:** chips 8, buttons 10, CTA/time-pills 11, cards 16, pills/badges 999.

**Layout.** Sections pad 56px horizontally. Hero is a ~56/44 split: copy left, floating
product card right. A "how it works" row of three steps uses big ghost numerals in
`--text-step`.

---

## ICONOGRAPHY

The product surface is text-and-time first and uses almost no icons. The two marks that DO appear:
- **The celestial body** — a **sun** (dawn/day/dusk) or **moon** (night) that arcs across the
  sky, drawn in CSS/inline SVG. It is both brand mark (moon at logo scale) and hero motif.
- **The Google "G"** — the standard four-color Google logo on the "Sign in with Google"
  button, since auth is Google-only. Rendered as inline SVG (see `assets/google-g.svg`).

No icon font, no emoji, no decorative iconography. If future surfaces need UI icons, use
**Lucide** (thin 1.5px stroke) to match the quiet, light feel — flagged as a substitution
since the source project ships none.

---

## INDEX / MANIFEST

Root
- `styles.css` — entry point; `@import`s the token + font layers below.
- `readme.md` — this file.
- `SKILL.md` — Agent-Skill wrapper.

`tokens/`
- `fonts.css` (Space Grotesk · Hanken Grotesk · **Fredoka** · Roboto)
- `colors.css` — legacy night tokens **+ the four `--m-*` mode palettes** (dawn/day/dusk/night)
- `typography.css` (`--font-display-mode` = Fredoka, `--font-google` = Roboto) · `spacing.css` · `effects.css`

`guidelines/` — foundation specimen cards (Type, Colors, Spacing, Brand) shown in the Design System tab.

`components/core/` — `Button`, `Card`, `Badge`, `TimeChip`, `MoonMark` (each `.jsx` + `.d.ts` + `.prompt.md`).

`ui_kits/website/` — the Lights Out marketing site recreation (`index.html` + screen JSX).

`assets/` — `google-g.svg` and any brand marks.

---

## Sources
- GitHub: https://github.com/fvclaus/no-meeting-overtime (original "No Meeting Overtime").
- Fonts: Space Grotesk + Hanken Grotesk (Google Fonts) — both available, no substitution needed.
