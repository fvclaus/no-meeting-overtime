import React from "react";

/** A selectable time option, mode-aware. The chosen one fills with the mode
 *  accent; others sit on the quiet track fill. */
export function TimeChip({ selected = false, children, style = {}, ...rest }) {
  return (
    <button
      {...rest}
      style={{
        flex: 1,
        textAlign: "center",
        font: selected ? "600 14px/1 var(--font-body)" : "500 14px/1 var(--font-body)",
        color: selected ? "var(--m-ink, var(--blue-ink))" : "var(--m-body, var(--text-body))",
        background: selected ? "var(--m-accent, var(--blue-500))" : "var(--m-track, var(--fill-05))",
        border: "1px solid " + (selected ? "transparent" : "var(--m-track-border, transparent)"),
        padding: "11px 0",
        borderRadius: "var(--radius-sm)",
        cursor: "pointer",
        transition: "background-color var(--dur-fast) var(--ease-soft)",
        ...style,
      }}
    >
      {children}
    </button>
  );
}
