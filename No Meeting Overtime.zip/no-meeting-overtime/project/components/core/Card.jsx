import React from "react";

/**
 * Translucent surface card that floats over the sky.
 * Reads the active mode's --m-* tokens (legacy night fallback). A blurred
 * mode-tinted fill with a hairline border; `floating` adds the deep shadow.
 */
export function Card({ floating = true, padding = "28px", radius = "var(--radius-xl)", style = {}, children, ...rest }) {
  return (
    <div
      {...rest}
      style={{
        background: "var(--m-card, var(--night-700))",
        border: "1px solid var(--m-card-border, var(--night-line-strong))",
        borderRadius: radius,
        padding,
        boxShadow: floating ? "var(--m-card-shadow, var(--shadow-card))" : "none",
        backdropFilter: "blur(6px)",
        WebkitBackdropFilter: "blur(6px)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}
