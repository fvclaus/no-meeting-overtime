Primary action button — use for "Start the call" and any single main action on a screen. It is **mode-aware**: it reads the active `data-mode`'s `--m-*` tokens, so the same button looks right in dawn, day, dusk and night.

```jsx
<div data-mode="dusk">
  <Button variant="primary" size="md">Start the call</Button>
</div>
```

Variants: `primary` (solid mode accent, the default), `secondary` (transparent with a card hairline — quieter), `ghost` (quiet track fill). Sizes: `md` (CTA) and `sm` (nav). Pill radius. Sentence case always; never more than one `primary` in a view; no scale on press.

**Do NOT use this for "Sign in with Google."** That button must follow Google's brand rules (Roboto Medium, the unaltered four-color G, an approved label, and Google's light *or* dark theme chosen by `--m-google-theme`). Build it separately — see the readme's "Google sign-in (compliance)" note.
