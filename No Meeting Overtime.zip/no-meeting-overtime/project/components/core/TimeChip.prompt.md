A row of these lets the user pick when the call ends — only the selected one is filled.

```jsx
<div style={{ display: "flex", gap: 8 }}>
  <TimeChip>11:00</TimeChip>
  <TimeChip selected>11:15</TimeChip>
  <TimeChip>11:30</TimeChip>
</div>
```

Always lay out in a flex row with `gap: 8`. Exactly one `selected` at a time.
