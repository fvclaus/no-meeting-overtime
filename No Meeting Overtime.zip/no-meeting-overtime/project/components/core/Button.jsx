import React from "react";

/**
 * HangUp / Lights Out button.
 * Reads the active mode's --m-* tokens (falls back to legacy night tokens when
 * no data-mode is set), so it restyles itself per dawn/day/dusk/night.
 *
 * variants:
 *   primary   — solid accent fill, --m-ink text, pill
 *   secondary — transparent with a card hairline + heading text, pill
 *   ghost     — quiet track fill (for tertiary actions)
 *
 * NOTE: the "Sign in with Google" button is NOT this component — it must follow
 * Google's brand rules (Roboto, fixed light/dark themes). See GoogleButton usage
 * in the readme.
 */
export function Button({
  variant = "primary",
  size = "md",
  full = false,
  leadingIcon = null,
  children,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { padding: "11px 18px", font: "var(--type-label)" },
    md: { padding: "15px 22px", font: "600 16px/1 var(--font-body)" },
  };
  const s = sizes[size] || sizes.md;

  const variants = {
    primary: {
      background: "var(--m-accent, var(--blue-500))",
      color: "var(--m-ink, var(--blue-ink))",
      border: "1px solid transparent",
    },
    secondary: {
      background: "transparent",
      color: "var(--m-heading, var(--text-bright))",
      border: "1px solid var(--m-card-border, var(--night-line-strong))",
    },
    ghost: {
      background: "var(--m-track, var(--fill-05))",
      color: "var(--m-heading, var(--text-bright))",
      border: "1px solid var(--m-track-border, var(--night-line-strong))",
    },
  };
  const v = variants[variant] || variants.primary;

  return (
    <button
      {...rest}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "10px",
        width: full ? "100%" : "auto",
        padding: s.padding,
        font: s.font,
        borderRadius: "var(--radius-pill)",
        cursor: "pointer",
        transition: "background-color var(--dur-fast) var(--ease-soft)",
        ...v,
        ...style,
      }}
    >
      {leadingIcon}
      {children}
    </button>
  );
}
