/* Lights Out — Signed-in "set the end time" screen. Attaches to window.SetTimeScreen.
   Shown after Google sign-in: choose tonight's end time, then start the call.
   Also renders a simple "scheduled" confirmation state. */
(function () {
  const { useState } = React;

  const TIMES = ["10:30", "11:00", "11:15", "11:30", "12:00", "12:30"];

  window.SetTimeScreen = function SetTimeScreen({ onBack }) {
    const [end, setEnd] = useState("11:15");
    const [started, setStarted] = useState(false);

    return (
      <div style={{ background: "var(--night-900)", minHeight: "100%", position: "relative", overflow: "hidden", fontFamily: "var(--font-body)", display: "flex", flexDirection: "column" }}>
        <div style={{ position: "absolute", top: 140, right: 90, width: 200, height: 200, borderRadius: "50%", background: "var(--moon)", boxShadow: "var(--moon-crescent), var(--moon-halo)", opacity: 0.4, animation: "lo-glow-pulse 6s ease-in-out infinite", pointerEvents: "none" }} />

        {/* top bar */}
        <div style={{ position: "relative", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "26px 56px", borderBottom: "1px solid var(--night-line)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
            <div style={{ width: 24, height: 24, borderRadius: "50%", background: "var(--moon)", boxShadow: "var(--moon-crescent-sm)" }} />
            <span style={{ font: "var(--type-logo)", letterSpacing: "var(--track-tight)", color: "var(--text-hi)" }}>Lights Out</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ font: "var(--type-ui)", color: "var(--text-muted)" }}>Mara Lindqvist</span>
            <div style={{ width: 30, height: 30, borderRadius: "50%", background: "var(--blue-500)", color: "var(--blue-ink)", display: "flex", alignItems: "center", justifyContent: "center", font: "600 13px/1 var(--font-body)" }}>M</div>
          </div>
        </div>

        {/* body */}
        <div style={{ position: "relative", flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "48px 56px" }}>
          <div style={{ width: 440, background: "var(--night-700)", border: "1px solid var(--night-line-strong)", borderRadius: "var(--radius-xl)", padding: 32, boxShadow: "var(--shadow-card)" }}>

            {!started ? (
              <React.Fragment>
                <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--track-eyebrow)", textTransform: "uppercase", color: "var(--accent)", marginBottom: 14 }}>Tonight's call</div>
                <h2 style={{ font: "700 28px/1.1 var(--font-display)", letterSpacing: "var(--track-tight)", color: "var(--text-bright)", margin: "0 0 6px" }}>When should it end?</h2>
                <p style={{ font: "var(--type-small)", color: "var(--text-faint)", margin: "0 0 24px" }}>We'll close the Meet call at this time. You can change it before you start.</p>

                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
                  <span style={{ font: "var(--type-display)", letterSpacing: "var(--track-display)", color: "var(--text-bright)" }}>{end} <span style={{ fontSize: 22, color: "var(--text-muted)" }}>PM</span></span>
                  <span style={{ font: "600 12px/1 var(--font-body)", color: "var(--blue-500)", border: "1px solid var(--blue-tint-40)", padding: "6px 10px", borderRadius: "var(--radius-pill)" }}>Auto</span>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, marginBottom: 24 }}>
                  {TIMES.map((t) => (
                    <button key={t} onClick={() => setEnd(t)} style={{ textAlign: "center", font: t === end ? "600 14px/1 var(--font-body)" : "500 14px/1 var(--font-body)", color: t === end ? "var(--blue-ink)" : "var(--text-body)", background: t === end ? "var(--blue-500)" : "var(--fill-05)", border: "none", padding: "12px 0", borderRadius: "var(--radius-sm)", cursor: "pointer" }}>{t}</button>
                  ))}
                </div>

                <button onClick={() => setStarted(true)} style={{ width: "100%", font: "600 15px/1 var(--font-body)", color: "var(--blue-ink)", background: "var(--blue-500)", padding: "15px 0", border: "none", borderRadius: "var(--radius-lg)", cursor: "pointer" }}>Start the call</button>
              </React.Fragment>
            ) : (
              <div style={{ textAlign: "center", padding: "8px 0" }}>
                <div style={{ width: 60, height: 60, borderRadius: "50%", background: "var(--moon)", boxShadow: "var(--moon-crescent-sm)", margin: "0 auto 22px" }} />
                <h2 style={{ font: "700 26px/1.15 var(--font-display)", letterSpacing: "var(--track-tight)", color: "var(--text-bright)", margin: "0 0 8px" }}>The call ends at {end} PM.</h2>
                <p style={{ font: "var(--type-small)", color: "var(--text-body)", margin: "0 0 24px", maxWidth: 320, marginInline: "auto" }}>Your Meet call is open. Talk for as long as you like — Lights Out closes it on time, so you don't have to.</p>
                <button onClick={() => setStarted(false)} style={{ font: "var(--type-label)", color: "var(--text-bright)", background: "var(--fill-05)", border: "1px solid var(--night-line-strong)", padding: "11px 18px", borderRadius: "var(--radius-md)", cursor: "pointer" }}>Change the time</button>
              </div>
            )}
          </div>
        </div>

        <div style={{ position: "relative", textAlign: "center", padding: "0 56px 40px", font: "var(--type-small)", color: "var(--text-faint)" }}>
          Free, non-profit, no ads.{onBack ? <span> · <span onClick={onBack} style={{ color: "var(--text-muted)", cursor: "pointer" }}>Sign out</span></span> : null}
        </div>
      </div>
    );
  };
})();
