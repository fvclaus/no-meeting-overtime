import React from "react";

export interface MoonMarkProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Diameter in px. Default 26 (nav scale). */
  size?: number;
  /** Render the "Lights Out" wordmark beside the moon. */
  withWord?: boolean;
  /** Add the breathing blue halo — for large hero placement. */
  glow?: boolean;
}

export declare function MoonMark(props: MoonMarkProps): JSX.Element;
