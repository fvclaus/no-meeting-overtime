import React from "react";

/**
 * The Lights Out brand mark: a crescent moon (inset shadow carves the circle).
 * `withWord` renders the logo lockup; `glow` adds the breathing halo for hero use.
 */
export function MoonMark({ size = 26, withWord = false, glow = false, style = {}, ...rest }) {
  const crescentInset = Math.max(4, Math.round(size * 0.27));
  const moon = (
    <span
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: "var(--moon)",
        boxShadow: glow
          ? `inset -${crescentInset + 11}px -${crescentInset + 1}px 0 0 var(--m-carve, var(--night-900)), var(--moon-halo)`
          : `inset -${crescentInset}px -${Math.round(crescentInset * 0.6)}px 0 0 var(--m-carve, var(--night-900))`,
        animation: glow ? "lo-glow-pulse 6s ease-in-out infinite" : "none",
        display: "block",
        flex: "none",
      }}
    />
  );
  if (!withWord) return React.cloneElement(moon, { ...rest, style: { ...moon.props.style, ...style } });
  return (
    <span {...rest} style={{ display: "inline-flex", alignItems: "center", gap: 11, ...style }}>
      {moon}
      <span style={{ font: "700 18px/1 var(--font-display-mode)", letterSpacing: "var(--track-tight)", color: "var(--m-heading, var(--text-hi))" }}>
        Lights Out
      </span>
    </span>
  );
}
