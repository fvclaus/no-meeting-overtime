/* Lights Out — Dashboard. Attaches to window.DashboardScreen.
   The signed-in home. The product only ever governs the ONE Google Meet call
   you're currently in: you set when it ends, and it ends itself. So this screen
   shows at most one running call — its end time, time left and progress — with
   the option to change the time or end it now. No call names, no participant
   lists, no scheduled future calls: the app doesn't know or invent any of that. */
(function () {
  const { useState } = React;

  function LiveDot() {
    return <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--blue-500)", boxShadow: "0 0 0 4px var(--blue-tint-22)", display: "inline-block" }} />;
  }

  function Stat({ label, value, accent }) {
    return (
      <div>
        <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--track-eyebrow)", textTransform: "uppercase", color: "var(--text-faint)", marginBottom: 7 }}>{label}</div>
        <div style={{ font: "700 30px/1 var(--font-display)", letterSpacing: "var(--track-tight)", color: accent ? "var(--blue-400)" : "var(--text-bright)" }}>{value}</div>
      </div>
    );
  }

  window.DashboardScreen = function DashboardScreen({ onNewCall, onSignOut }) {
    // At most one call — the Meet you're in right now.
    const [call, setCall] = useState({ endsAt: "11:15 PM", left: "1h 08m", progress: 62 });

    return (
      <div style={{ background: "var(--night-900)", minHeight: "100%", fontFamily: "var(--font-body)" }}>
        {/* top bar */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "26px 56px", borderBottom: "1px solid var(--night-line)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
            <div style={{ width: 24, height: 24, borderRadius: "50%", background: "var(--moon)", boxShadow: "var(--moon-crescent-sm)" }} />
            <span style={{ font: "var(--type-logo)", letterSpacing: "var(--track-tight)", color: "var(--text-hi)" }}>Lights Out</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <span style={{ font: "var(--type-ui)", color: "var(--text-muted)" }}>Mara Lindqvist</span>
            <div onClick={onSignOut} style={{ width: 30, height: 30, borderRadius: "50%", background: "var(--blue-500)", color: "var(--blue-ink)", display: "flex", alignItems: "center", justifyContent: "center", font: "600 13px/1 var(--font-body)", cursor: "pointer" }}>M</div>
          </div>
        </div>

        {/* content */}
        <div style={{ maxWidth: 620, margin: "0 auto", padding: "60px 56px 72px" }}>
          {/* heading */}
          <div style={{ marginBottom: 30 }}>
            <h1 style={{ font: "700 34px/1.1 var(--font-display)", letterSpacing: "var(--track-tight)", color: "var(--text-bright)", margin: "0 0 8px" }}>Good evening, Mara.</h1>
            <p style={{ font: "var(--type-lead)", color: "var(--text-body)", margin: 0 }}>
              {call
                ? <>Your call is running. Lights Out will close it at {call.endsAt} — nothing for you to do.</>
                : <>No call running right now. Start one and pick when it should end.</>}
            </p>
          </div>

          {call ? (
            <React.Fragment>
              <div style={{ font: "var(--type-eyebrow)", letterSpacing: "var(--track-eyebrow)", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 14 }}>Running now</div>

              <div style={{ background: "var(--night-700)", border: "1px solid var(--night-line-strong)", borderRadius: "var(--radius-xl)", padding: 30, position: "relative", overflow: "hidden", boxShadow: "var(--shadow-card)" }}>
                {/* progress toward end time */}
                <div style={{ position: "absolute", left: 0, bottom: 0, height: 3, width: call.progress + "%", background: "var(--blue-500)", opacity: 0.7 }} />

                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 22 }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 8, font: "600 11px/1 var(--font-body)", letterSpacing: ".06em", textTransform: "uppercase", color: "var(--blue-500)", border: "1px solid var(--blue-tint-40)", padding: "6px 10px", borderRadius: "var(--radius-pill)" }}><LiveDot /> Live</span>
                  <span style={{ font: "var(--type-small)", color: "var(--text-faint)" }}>End time is local</span>
                </div>

                <div style={{ font: "600 19px/1.3 var(--font-body)", color: "var(--text-bright)", marginBottom: 6 }}>Your Google Meet call is open.</div>
                <p style={{ font: "var(--type-small)", color: "var(--text-muted)", margin: "0 0 26px", maxWidth: 380 }}>Talk for as long as you like. Lights Out closes the call at the time you set, so you don't have to watch the clock.</p>

                <div style={{ display: "flex", gap: 56, paddingBottom: 26, borderBottom: "1px solid var(--night-line)" }}>
                  <Stat label="Ends" value={call.endsAt} />
                  <Stat label="Time left" value={call.left} accent={call.left.startsWith("0")} />
                </div>

                <div style={{ display: "flex", gap: 12, marginTop: 24 }}>
                  <button onClick={onNewCall} style={{ font: "var(--type-label)", color: "var(--text-bright)", background: "var(--fill-05)", border: "1px solid var(--night-line-strong)", padding: "12px 18px", borderRadius: "var(--radius-md)", cursor: "pointer" }}>Change end time</button>
                  <button onClick={() => setCall(null)} style={{ font: "var(--type-label)", color: "var(--text-bright)", background: "var(--fill-05)", border: "1px solid var(--night-line-strong)", padding: "12px 18px", borderRadius: "var(--radius-md)", cursor: "pointer" }}>End now</button>
                </div>
              </div>
            </React.Fragment>
          ) : (
            <div style={{ background: "var(--night-700)", border: "1px solid var(--night-line)", borderRadius: "var(--radius-xl)", padding: "44px 34px", textAlign: "center" }}>
              <div style={{ width: 48, height: 48, borderRadius: "50%", background: "var(--moon)", boxShadow: "var(--moon-crescent-sm)", margin: "0 auto 18px" }} />
              <div style={{ font: "600 18px/1.3 var(--font-body)", color: "var(--text-bright)", marginBottom: 7 }}>No call running.</div>
              <div style={{ font: "var(--type-small)", color: "var(--text-muted)", marginBottom: 24 }}>Start a call and pick the time it should end.</div>
              <button onClick={onNewCall} style={{ font: "600 15px/1 var(--font-body)", color: "var(--blue-ink)", background: "var(--blue-500)", padding: "13px 22px", border: "none", borderRadius: "var(--radius-lg)", cursor: "pointer" }}>New call</button>
            </div>
          )}

          <div style={{ font: "var(--type-small)", color: "var(--text-faint)", marginTop: 30 }}>Free, non-profit, no ads.</div>
        </div>
      </div>
    );
  };
})();
